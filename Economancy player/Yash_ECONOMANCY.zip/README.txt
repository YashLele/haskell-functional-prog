For Windows:
Just run the EconPlayer.exe file from Executables.
For Linux:
Just run the EconPlayer file from Executables.