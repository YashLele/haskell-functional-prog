For Windows:
Just run the Executables\EconPlayer.exe file.
For Linux:
Just run the Executables/EconPlayer file.